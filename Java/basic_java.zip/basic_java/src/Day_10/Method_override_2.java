package Day_10;

public class Method_override_2 extends Method_overriding {
	public void add(int x, int z) {
		System.out.println("Addition is "+(x+z+100));
	}
	public void display (int a ) {
		System.out.println("display integer from chile class "+ (a+100));
	}
	
	public static void main (String args []) {
		Method_override_2 m= new Method_override_2();
		m.add(10, 8);
		m.display(56);
		
	}

}
