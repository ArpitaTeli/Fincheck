package Day_10;

public class Method_overriding{
	
	public void add (int x , int y) {
		System.out.println("addition from first parent is "+(x+y));
	}
	
	public void display (int a ) {
		System.out.println("display integer from parent class "+a);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
