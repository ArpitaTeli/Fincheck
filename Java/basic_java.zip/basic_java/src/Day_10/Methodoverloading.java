package Day_10;

public class Methodoverloading {
	public void display(int a ) {
		System.out.println("Displayeing from 1st display method");
	}
	public void display (char s) {
		System.out.println ("Displaying 2nd display method");
	}
	public void add (int a , double b) {
		System.out.println("addidtion is" +(a+b));
	}
	public void add(double m, int n ) {
		System.out.println("addition is" +(m+n));
	}
	public void add (int x, int z) {
		System.out.println("addition is"+ (x+z));
	}
	
	public void add (int x , int y,int z ) {
		System.out.println("addition is"+ (x+y+z));
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Methodoverloading o= new Methodoverloading ();
		
		o.display (56);
		o.display ('5');
		o.add(23, 7855);
		o.add(2553, 78);
		o.add(23, 78,77);
	}

}
