package Day_11;

public class Encap1 {
	int d  =200;
	public int z= 34;
	private int a = 55;
	protected int b=100;
	
	private void add()
	{
		int m =90, n= 2; 
		System.out.println("addition is :" +(m+n));
		}
	protected void mul() {
		int s =90, t=2;
		System.out.println("multiplication is :"+(s+t));
		
	}
	void sub () {
		int x=10,y=50;
		System.out.println("subtraction is:"+(x-y));
	}
	public void div () {
		int x=10,y=50;
		System.out.println("division is :"+(x/y));
	}
	
	
}
