package Day_11;
public class Encap2 extends Encap1 {
	
		public static void mian (String args []) {
			Encap2 e =new Encap2();
			System.out.println ("value of d : "+e.d);
			System.out.println ("value of d : "+e.z);
			System.out.println ("value of d : "+e.b);
			//System.out.println ("value of d : "+e.a);
			
			
			//e.add ();
			e.mul();
			e.sub();
			e.div();
			
			
		}
	}


