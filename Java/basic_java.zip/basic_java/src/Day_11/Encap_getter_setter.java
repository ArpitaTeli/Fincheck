package Day_11;

public class Encap_getter_setter {
	private int a;
	public int getter_a () {
		return a;
	}
	public void setter_a(int c) {
		this.a=c;
		
	}
	public static void main(String args[]) {
		Encap_getter_setter m= new Encap_getter_setter();
		m.setter_a(25);
		System.out.println(m.getter_a());
	}
	
	

}
