package Day_13;
import java.util.Scanner;



public abstract class Area {
	public abstract void area (double x);
	
}