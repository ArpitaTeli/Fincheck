package Day_13;

public interface AreaInterface {
	public void area (double a , double b);

}
