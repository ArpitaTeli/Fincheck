package Day_13;

import java.util.Scanner;

public class AreaofRect implements AreaInterface, Shape{
	public void draw () {
	
		System.out.println("this is rectangle ");
		
	}
	public void area (double l,double b) {
		double area =l*b;
		System.out.println("area of rectangle "+area );
	}
	

	public static void main(String[] args) {
		
		AreaofRect a =new AreaofRect ();
		Scanner sc =new Scanner (System.in);
		System.out.println("enter l of rect");
		double l =sc.nextDouble ();
		System.out.println("enter l of rect");
		double b =sc.nextDouble ();
		a.draw ();
		a.area(l, b);
		sc.close();
	}

}
