package Day_13;

public class AreaofTri implements AreaInterface, Shape {

	public static void main(String[] args) {
		public void draw () {
			
			System.out.println("this is rectangle ");
		}
		

	}

}
