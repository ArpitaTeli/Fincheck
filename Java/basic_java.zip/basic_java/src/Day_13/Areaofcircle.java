package Day_13;
import java.util.Scanner;

public class Areaofcircle extends Area {
	
	public void area (double r) {
		double pi =3.14;
		double area =pi*r*r;
		
		System.out.println("area of circle "+ area);
		
	
		
	}
	
	
	public static void main (String args[]) {
		Area a =new Areaofcircle ();
		Scanner sc =new Scanner (System.in);
		System.out.println("Enter radius of circle");
		double r =sc.nextDouble ();
		a.area(r);
		sc.close();
	}

	
}

