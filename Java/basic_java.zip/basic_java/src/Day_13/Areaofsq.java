package Day_13;
import java.util.Scanner;

public class Areaofsq extends Area  {
	public void area (double s) {
		
			
			double areaofsqure =s*s;
			System.out.println("Area of sq:"+areaofsqure);
			
	}
	public static void main (String args[]) {
		Area a =new Areaofsq ();//upcasting
		
		Scanner sc =new Scanner (System.in);
		System.out.println("Enter side length");
		double s =sc.nextDouble ();
		a.area(s);
		sc.close();
	}
	
}
