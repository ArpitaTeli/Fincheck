package Day_13;

public interface Shape  {
	public void draw();
}
