package Day_14;

public class ArrayException {
    public static void main(String args[]) {
        int a[] = {1, 2, 59, 1142};

        try {
            for (int i = 0; i <= a.length; i++) {
                System.out.println(a[i]);
            }
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}