package Day_14;
import java.util.Scanner;
public class Divide_exception {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("enter 2 number");
		int num1 = sc.nextInt ();
		int num2 = sc.nextInt ();
		int result =0;
		try {
			result = num1/num2;
			System.out.println("results are:" + result);
		}
		catch (Exception e) {
			System.out.println("cant divide " +e.getMessage());
		}				
		System.out.println("program executed successfully");
	}

}
