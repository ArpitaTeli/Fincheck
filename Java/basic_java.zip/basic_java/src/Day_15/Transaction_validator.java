package Day_15;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileWriter;
import java.util.Scanner;
public class Transaction_validator{

		    public static void main(String[] args){
		        try {
		            File file = new File("Transaction.txt");
		            Scanner scanner = new Scanner(file);
		            FileWriter log =new FileWriter ("validation_log.txt");


		            while (scanner.hasNextLine()) {
		                String line = scanner.nextLine();
		                double amount = Double.parseDouble(line);

		                if (amount > 0) {
		                	log.write(amount + ": VALID\n");
		                    System.out.println("Amount: " + amount + " -> VALID");
		                } else {
		                	log.write(amount + ": INVALID\n");
		                    System.out.println("Amount: " + amount + " -> INVALID");
		                }
		            }

		            scanner.close();
		            log.close();
		            System.out.println("successfull");
		        }catch (IOException e) {
		            System.out.println("Error while writing the log file.");
		        } catch (NumberFormatException e) {
		            System.out.println("Error: Invalid number format in file.");
		        }
		    
		}
		
	}