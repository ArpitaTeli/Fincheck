package Day_2;

public class Customer {
	public static void main  (String args[]){
		System.out.println("hello world");
		int customer_id =1234;
		String customer_name = "Arpita Teli";
		String mail= "arpitateli02@gmail.com";
		long phone_no= 1234567890L;
		String City ="vashi";
		
		
		System.out.println ("customer_id" +customer_id);
		System.out.println ("customer_id" +customer_name);
		System.out.println ("customer_id" +mail);
		System.out.println ("customer_id" +phone_no);
		System.out.println ("customer_id" +City);
		
		
		
	}

}
