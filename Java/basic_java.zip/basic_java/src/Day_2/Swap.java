package Day_2;
import java.util.Scanner;
public class Swap {
	public static void main (String args[]) {
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter a:");
		int a =sc.nextInt ();
		System.out.println ("Enter b:");
		int b =sc.nextInt ();
		System.out.println("before swapping a "+a+" b:"+b);
		
		int temp=a;
		a=b;
		b=temp;
		System.out.println ("after swapping a="+a+ " b"+b);
		
	}

}
