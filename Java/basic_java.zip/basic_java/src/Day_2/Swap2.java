package Day_2;
import java.util.Scanner;

public class Swap2 {
	public static void main (String args[]) {
		Scanner sc = new Scanner (System.in);
		System.out.println("ENter a:");

		int a =sc.nextInt();
		
		System.out.println("ENter b:");
		
		int b =sc.nextInt();
		
		System.out.println("before swapping a:"+a+ "b: "+b);
		
		a=a+b;
		b=a-b;
		a=a-b;
		
		System.out.println("after swapping a:"+a+ "b: "+b);

	}

}
