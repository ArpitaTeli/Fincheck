package Day_3;

import java.util.Scanner;

public class Area_circle {
	public static void main (String args[]) {
		Scanner sc= new Scanner (System.in);
		
		float  pi = 3.14f;
		
		System.out.println("enter R:");
		int r= sc.nextInt();
		
		
		System.out.println ("Area of circle :" +(pi*r*r));
		
		
	}
}
