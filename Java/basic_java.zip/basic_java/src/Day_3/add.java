package Day_3;
import java.util.Scanner;
public class add {
	public static void main (String args[]) {
		Scanner sc= new Scanner (System.in);
		
		System.out.println("ENter a:");

		int a = sc.nextInt();
		
		
		System.out.println("ENter b:");

		int b = sc.nextInt();


		int c= a+b;
		System.out.println(c);
		
	}
}

