package Day_4;
import java.util.Scanner;
public class If_else {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Scanner sc = new Scanner(System.in);
			
			System.out.println ("Enter Age");
			int age = sc.nextInt();
			
			if (age <= 18) {
				System.out.println("you are minor ");
				
			}
			else {
				System.out.println("you are adult");
			}
	
	}

}
