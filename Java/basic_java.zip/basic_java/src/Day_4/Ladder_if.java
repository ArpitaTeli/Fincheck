package Day_4;
import java.util.Scanner;

public class Ladder_if {

	public static void main(String[] args) {
		Scanner sc =new Scanner (System.in);
		System.out.println ("enter your percentage");
		
		float marks= sc.nextFloat();
		if (marks>=90) {
			System.out.println("Outstanding");
		}
		else if (marks>=80) {
			System.out.println("A grade");

		}
		else if (marks>=70) {
			System.out.println("B grade");

		}
		else if (marks>=60) {
			System.out.println("C grade");

		}
		else if (marks>=50) {
			System.out.println("D grade");

		}
		else {
			System.out.println("you are fail");

		}
		
sc.close();z
	}

}
