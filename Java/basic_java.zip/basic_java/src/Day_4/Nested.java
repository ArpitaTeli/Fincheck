package Day_4;
import java.util.Scanner;
public class Nested {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		System.out.println("enetr age");
		int age =sc.nextInt();
		if (age < 60) {
			if (age>=18) {
				System.out.println("u are eligible for licence ");
				
			}
			else {
				System.out.println("you are not eligible");
			}
			
		}
		else {
			System.out.println("you are senior citizen");
		
		}
	}

}
