package Day_5;
import java.util.Scanner;
public class Dowhile {
	public static void main (String args []) {
		Scanner sc =new Scanner (System.in);
		
		int sum =0;
		int num;
		
		do {
			System.out.println ("Enter number :");
			num=sc.nextInt();
			sum +=num ;
			
		}while (num !=0);
		System.out.println ("total sum of all numbers is "+ sum);
		
	}

}
