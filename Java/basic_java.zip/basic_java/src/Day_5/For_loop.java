package Day_5;
import java.util.Scanner;
public class For_loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number");
		
		
		int a =sc.nextInt();
		
		for (int i=1; i<= 10; i++  ) {
			System.out.println (a +"*" + i + "=" +(a*i));
		}
	}

}
