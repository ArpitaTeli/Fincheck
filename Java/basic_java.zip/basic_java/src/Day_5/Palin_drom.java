package Day_5;

import java.util.Scanner;

public class Palin_drom {

    public static void main(String[] args) { // Fixed: Removed the duplicate main declaration
        Scanner sc = new Scanner(System.in);
        System.out.println("enter number");
        
        int num = sc.nextInt();
        int rev = 0, temp = 0; // Fixed: Removed ',p' from here to avoid duplicate declaration
        int p = num;
        
        while (num != 0) {
            temp = num % 10;
            rev = rev * 10 + temp;
            num = num / 10;
        }
        
        System.out.println("reverse number is " + rev);
        
        if (p == rev) {
            System.out.println(p + " is a palindrome");
        } else {
            System.out.println(p + " is not a palindrome");
        }
        
        sc.close(); 
    } // Fixed: Removed the extra closing bracket
}
