package Day_5;
import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner (System.in);
		System.out.println("enter number");
		
		int num = sc.nextInt();
		int rev =0, temp=0,p;
		int p = num;
		
		while(num != 0) {
			temp= num%10;
			rev =rev *10+temp;
			num =num /10;
			
		}
		System.out.println ("reverese number is "+ rev );
		if (p== rev) {
			System.out.println(p +" is a palindrome");
		}
		else {
			System.out.println(p +" is not  a palindrome");

		}

	}

}
