package Day_5;
import java.util.Scanner ;

public class While_loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner (System.in);
		
		while(true) {
			int a = sc.nextInt();

			if ( a == 0) {
				System.out.println("program stopped");
				break; 
			}
			else {
				System.out.println ("your number is "+a);
			}
		}
	}

}
