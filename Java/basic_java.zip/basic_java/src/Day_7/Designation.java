package Day_7;
import java.util.Scanner;

public class Designation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		System.out.println("enter your name ");
		String name = sc.nextLine();
		System.out.println("enter your designation ");
		String post = sc.nextLine();
		System.out.println("enetr your salary");
		int sal =sc.nextInt();
		
		if (post.equalsIgnoreCase("Manager")) {
			System.out.println(name + " ur incremental salary is: "+ (sal+10000));
		}
		else if (post.equalsIgnoreCase("Clerk")) {
			System.out.println(name + " ur incremental salary is: "+ (sal+1000));
		}
		else if (post.equalsIgnoreCase("Offlice boy")) {
			System.out.println(name + " ur incremental salary is: "+ (sal+500));
		}
		else {
			System.out.println("not applicable");
		}
		
	}

}
