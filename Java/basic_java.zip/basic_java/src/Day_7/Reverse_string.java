package Day_7;

public class Reverse_string {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ori ="hello";
		String rev ="";
		
		for (int i= ori.length()-1 ; i>=0 ; i--) {
			rev += ori.charAt(i);
		}
		System.out.println ("Original: "+ ori);
		System.out.println ("Reversed: "+ rev );
		
	}

}
