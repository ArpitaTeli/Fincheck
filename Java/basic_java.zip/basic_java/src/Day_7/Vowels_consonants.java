package Day_7;

public class Vowels_consonants {

	public static void main(String[] args) {
		int vCount = 0, cCount = 0, Space = 0;
		
		String str = "Sun Rises in the east";
		
		str = str.toLowerCase();
		
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i); 
			
			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
				vCount++;
			}
			else if (ch >= 'a' && ch <= 'z') {
				cCount++;
			}
			else {
				Space++;
			}
		}
		
		System.out.println("Vowels: " + vCount);
		System.out.println("Consonants: " + cCount);
		System.out.println("Spaces/Special Characters: " + Space);
	}
}
