package Day_7;
import java.util.Scanner;

public class Word {
	public static void main (String args []) {
		Scanner sc = new Scanner (System.in);
		System.out.println ("Enter a string: ");
		String str = sc.nextLine();
		
		System.out.println("what are you looking for ?");
		String f = sc.next();
		
		if (str.contains(f)) {
			System .out.println(f + " was found");
			
		}
		else {
			System.out.println (f+ "not found");
		}
	}
	

}
