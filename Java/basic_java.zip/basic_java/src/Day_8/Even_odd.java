package Day_8;

import java.util.Scanner;
class Single_inheritance {	
	public int Grt_no (int a , int b ) {
		if (a!=b ) {
			if (a>b) {
				return a;
			}
			else {
				return b;
			}
		}
		else {
			return 0;
			}
			
		
		}
		
	}

	
	public class Even_odd extends Single_inheritance{
		public void evenodd (int c ) {
			if (c % 2==0) {
				System.out.println (c+ " is Even number ");
			}
			else {
				System.out.println (c+ " is odd number");
			}
			
		}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		System.out.println ("ENter 1st number");
		int a = sc.nextInt();
		System.out.println ("ENter 2nd number");
		int b = sc.nextInt ();
		
		Even_odd o = new Even_odd();
		
		int g= o.Grt_no (a,b);
		
		if (g!=0) {
			System.out.println ("largest value from "+a+ " and "+b+ " is "+ g);
			o.evenodd(g);
			
		}
		else {
			System.out.println ("both are equal");
			o.evenodd(a);
		}
		

	}

}
