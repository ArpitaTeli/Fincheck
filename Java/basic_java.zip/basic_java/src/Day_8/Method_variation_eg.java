package Day_8;

public class Method_variation_eg {
	public void add(int a,int b) {
		int add = a+b ;
		System.out.println ("Addition is :" +add);
		
	}
	public int sub (int a, int b) {
		int sub= a-b;
		return sub;
		
	}
	public void multiply () {
		int m=50 , n=20;
		
		System.out.println ("Multiplication is :" +(m*n));
	}
	public int div() {
		int m =100,n=2;
		return m/n;
	}
	
	public static void main (String args[]) {
		
		Method_variation_eg mv =new Method_variation_eg ();
		
		mv.add(5, 8);
		
		int s = mv.sub(41, 5);
		System.out.println("Subtraction is: " + s);
		
		mv.multiply();
		
		int d = mv.div();
		System.out.println("Division is: " + d);
		
		System.out.println("program is done ");
	}

}
