package Day_9;

import java.util.Scanner;

// Renamed to avoid duplicate name conflict
class Grater_number_v2 {
    public int Grt_no(int a, int b) {
        if (a != b) {
            if (a > b) {
                return a;
            } else {
                return b;
            }
        } else {
            return 0;
        }
    }
}

// Renamed to avoid duplicate name conflict
class Even_odd_v2 extends Grater_number_v2 {
    public void evenodd(int c) {
        if (c % 2 == 0) {
            System.out.println(c + " is Even number ");
        } else {
            System.out.println(c + " is odd number");
        }
    }
}

// Renamed to avoid duplicate name conflict
class Posi_negi_v2 extends Even_odd_v2 {
    public void pn(int grt) {
        if (grt > 0) {
            System.out.println("its a positive number ");
        } else {
            System.out.println("its -ve number");
        }
    }
}

public class Hybrid_inheritance {
    public static void rev(int num) {
        int temp, rev = 0;
        while (num != 0) {
            temp = num % 10;
            rev = rev * 10 + temp;
            num = num / 10;
        }
        System.out.println("reverse num is: " + rev);
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("ENter 1st number");
        int a = sc.nextInt();
        System.out.println("ENter 2nd number");
        int b = sc.nextInt();
        
        // Using the newly renamed child class instance
        Posi_negi_v2 o = new Posi_negi_v2();
      
        int grt = o.Grt_no(a, b);
        
        if (grt != 0) {
            System.out.println("largest value is " + grt);
            o.evenodd(grt);
            o.pn(grt);
            rev(grt); 
        } else {
            System.out.println("both are equal");
            o.evenodd(a);
        }
        sc.close();
    }
}
