package Day_9;

import java.util.Scanner;

// 1. First class
class Greater_Number {    
    public int Grt_no(int a, int b) {
        if (a != b) {
            if (a > b) {
                return a;
            } else {
                return b;
            }
        } else {
            return 0;
        }
    }
}

// 2. Second class (Correctly closed with })
class Even_odd extends Greater_Number {
    public void evenodd(int c) {
        if (c % 2 == 0) {
            System.out.println(c + " is Even number ");
        } else {
            System.out.println(c + " is odd number");
        }
    }
}

// 3. Third class (Correctly closed with })
class Posi_negi extends Even_odd {
    public void pn(int grt) {
        if (grt > 0) {
            System.out.println("its a positive number ");
        } else {
            System.out.println("its -ve number");
        }
    }
}

// 4. Main Class matching your file name "Multiple_inheritance.java"
public class Multilevel_inheritance {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("ENter 1st number");
        int a = sc.nextInt();
        System.out.println("ENter 2nd number");
        int b = sc.nextInt();
        
        Posi_negi o = new Posi_negi();
        int grt = o.Grt_no(a, b);
        
        if (grt != 0) {
            System.out.println("largest value is " + grt);
            o.evenodd(grt);
            o.pn(grt);
        } else {
            System.out.println("both are equal");
            o.evenodd(a);
        }
        
        sc.close();
    }
}
