package Day_9;

public class tran_method {

		static void validate (int amount) {
			if (amount >0) {
				System.out.println(amount +" : valid");
			}
			else {
				System.out.println (amount +": INvalid");
			}
				
	}
		public static void main (String args[]) {
			validate (5000);
			validate (-10000);
			validate(0);
			validate (6565);
			
		}
}


