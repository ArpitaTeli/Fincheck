package day_one;

public class Hello {

	public static void main(String[] args) {
		System.out.println("hello java");
		

	}

}
