package demo3;
import Day_11.*;

public class Encap3 extends Encap1 {
	public static void main (String args []) {
		Encap3 e = new Encap3 ();
		e.mul();
		e.div();
		//e.add ();
		//e.sub();
		
	}
	

}
