package file_handling_day_14;
import java.util.Scanner;
import java.io.*;


public class File_handle {
	

	public static void main(String[] args) {
		try {
		File f=new File (".//Transaction.txt");
		Scanner sc =new Scanner (f);
		while (sc.hasNextLine()){
			System.out.println(sc.nextLine());
		}
		sc.close();
	}
		catch (Exception e) {
			System.out.println(e);
		}
	
	}
}
