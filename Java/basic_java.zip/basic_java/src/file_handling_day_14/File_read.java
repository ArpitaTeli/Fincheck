package file_handling_day_14;
import java.io.*;

public class File_read {

	public static void main(String[] args) {
		try {
			FileReader read = new FileReader (".//sample.txt");
			int character ;
			while ((character =read.read())!=-1) {
				System.out.print((char) character);
			}
			read.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
