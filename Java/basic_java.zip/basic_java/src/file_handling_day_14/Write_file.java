package file_handling_day_14;
import java.io.*;
public class Write_file {

	public static void main(String[] args) {
		try {
			FileWriter writer =new FileWriter ("sample.txt");
			writer.write("hello, writing the 2nd line ");
			writer.close();
			System.out.println("Successfully written");
		}catch (Exception e) {
			 System.out.println(e);
		}
	}

}
